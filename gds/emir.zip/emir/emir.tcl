# EM/IR analysis on the as-shipped D10_D layout (post-PDN-fix).
# gf180mcuD, nom_tt_025C_5v00, VDD = 5.0 V.
read_lef /foss/pdks/gf180mcuD/libs.ref/gf180mcu_fd_sc_mcu7t5v0/techlef/gf180mcu_fd_sc_mcu7t5v0__nom.tlef
read_lef /foss/pdks/gf180mcuD/libs.ref/gf180mcu_fd_sc_mcu7t5v0/lef/gf180mcu_fd_sc_mcu7t5v0.lef
read_lef /work/vdd_conn.lef
read_lef /work/vss_conn.lef
read_liberty /foss/pdks/gf180mcuD/libs.ref/gf180mcu_fd_sc_mcu7t5v0/lib/gf180mcu_fd_sc_mcu7t5v0__tt_025C_5v00.lib
read_def /work/D10_D.def
read_sdc /work/D10_D.sdc

puts "===== POWER-GRID CONNECTIVITY ====="
check_power_grid -net VDD
check_power_grid -net VSS

set_pdnsim_net_voltage -net VDD -voltage 5.0
puts "===== IR/EM ANALYSIS: net VDD ====="
analyze_power_grid -net VDD -voltage_file /work/net-VDD.csv -enable_em -em_outfile /work/em-VDD.csv
set_pdnsim_net_voltage -net VSS -voltage 0
puts "===== IR/EM ANALYSIS: net VSS ====="
analyze_power_grid -net VSS -voltage_file /work/net-VSS.csv -enable_em -em_outfile /work/em-VSS.csv
